import { useState } from 'react'
import { getRecipes } from '../api/client'

export default function Ingredients({ ingredients, onDone }) {
  const [selected, setSelected] = useState(ingredients)
  const [loading, setLoading] = useState(false)

  const toggle = (ing) =>
    setSelected(prev => prev.includes(ing) ? prev.filter(i => i !== ing) : [...prev, ing])

  const handleGenerate = async () => {
    setLoading(true)
    try {
      const res = await getRecipes(selected)
      onDone(res.data.recipes)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '60px 24px' }}>
      <h2 style={{ fontSize: 36, fontWeight: 700, marginBottom: 8 }}>
        Found {ingredients.length} ingredients
      </h2>
      <p style={{ color: 'rgba(245,240,232,0.5)', marginBottom: 32 }}>
        Toggle what you want to use
      </p>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, marginBottom: 40 }}>
        {ingredients.map(ing => (
          <button key={ing} onClick={() => toggle(ing)} style={{
            padding: '12px 20px', borderRadius: 12, cursor: 'pointer', fontSize: 15,
            background: selected.includes(ing) ? 'rgba(245,158,11,0.2)' : 'rgba(245,240,232,0.05)',
            border: `1px solid ${selected.includes(ing) ? '#f59e0b' : 'rgba(245,240,232,0.1)'}`,
            color: '#f5f0e8'
          }}>{ing}</button>
        ))}
      </div>

      <button onClick={handleGenerate} disabled={loading || selected.length === 0} style={{
        background: 'linear-gradient(135deg, #f59e0b, #ef4444)',
        border: 'none', borderRadius: 12, padding: '16px 36px',
        color: '#0f0e0c', fontWeight: 700, fontSize: 16, cursor: 'pointer'
      }}>
        {loading ? 'Generating recipes...' : `Generate recipes →`}
      </button>
    </div>
  )
}