import { useState } from 'react'

export default function Recipes({ recipes, onReset }) {
  const [selected, setSelected] = useState(null)

  if (selected) return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '60px 24px' }}>
      <button onClick={() => setSelected(null)} style={{
        background: 'none', border: 'none', color: 'rgba(245,240,232,0.5)',
        cursor: 'pointer', fontSize: 14, marginBottom: 32
      }}>← Back</button>
      <h2 style={{ fontSize: 32, fontWeight: 700, marginBottom: 24 }}>{selected.name}</h2>
      <div style={{ display: 'flex', gap: 24, marginBottom: 32, color: 'rgba(245,240,232,0.5)' }}>
        <span>⏱ {selected.time}</span>
        <span>📊 {selected.difficulty}</span>
        <span>🔥 {selected.calories} kcal</span>
      </div>
      <h3 style={{ color: '#f59e0b', fontSize: 13, letterSpacing: '0.1em', marginBottom: 16 }}>INGREDIENTS</h3>
      {selected.ingredients?.map((ing, i) => (
        <div key={i} style={{ padding: '10px 0', borderBottom: '1px solid rgba(245,240,232,0.06)' }}>{ing}</div>
      ))}
      <h3 style={{ color: '#f59e0b', fontSize: 13, letterSpacing: '0.1em', margin: '32px 0 16px' }}>STEPS</h3>
      {selected.steps?.map((step, i) => (
        <div key={i} style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
          <div style={{
            width: 28, height: 28, borderRadius: '50%', background: 'rgba(245,158,11,0.2)',
            color: '#f59e0b', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 13, fontWeight: 700, flexShrink: 0
          }}>{i + 1}</div>
          <div style={{ paddingTop: 4, lineHeight: 1.6 }}>{step}</div>
        </div>
      ))}
    </div>
  )

  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '60px 24px' }}>
      <h2 style={{ fontSize: 36, fontWeight: 700, marginBottom: 8 }}>Your recipes</h2>
      <p style={{ color: 'rgba(245,240,232,0.5)', marginBottom: 32 }}>Click to see full recipe</p>

      {recipes.map((r, i) => (
        <div key={i} onClick={() => setSelected(r)} style={{
          padding: '24px', borderRadius: 16, marginBottom: 16, cursor: 'pointer',
          background: 'rgba(245,240,232,0.03)', border: '1px solid rgba(245,240,232,0.08)'
        }}>
          <h3 style={{ fontSize: 22, fontWeight: 700, marginBottom: 8 }}>{r.name}</h3>
          <div style={{ color: 'rgba(245,240,232,0.5)', fontSize: 14, display: 'flex', gap: 20 }}>
            <span>⏱ {r.time}</span>
            <span>📊 {r.difficulty}</span>
            <span>🔥 {r.calories} kcal</span>
          </div>
        </div>
      ))}

      <button onClick={onReset} style={{
        marginTop: 16, background: 'none', border: '1px solid rgba(245,240,232,0.2)',
        borderRadius: 10, padding: '12px 24px', color: 'rgba(245,240,232,0.6)', cursor: 'pointer'
      }}>← Start over</button>
    </div>
  )
}