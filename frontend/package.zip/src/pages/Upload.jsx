import { useRef, useState } from 'react'
import { analyzeImage } from '../api/client'

export default function Upload({ onDone }) {
  const fileRef = useRef()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleFile = async (file) => {
    if (!file) return
    setLoading(true)
    setError('')
    try {
      const res = await analyzeImage(file)
      onDone(res.data.ingredients)
    } catch (e) {
      setError('Failed to analyze image. Try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '80px 24px', textAlign: 'center' }}>
      <div style={{ fontSize: 56, marginBottom: 24 }}>🍳</div>
      <h1 style={{ fontSize: 48, fontWeight: 700, marginBottom: 16 }}>FridgeAI</h1>
      <p style={{ color: 'rgba(245,240,232,0.5)', marginBottom: 48, fontSize: 18 }}>
        Photo your fridge — get instant recipes
      </p>

      <div
        onClick={() => fileRef.current.click()}
        style={{
          border: '2px dashed rgba(245,240,232,0.2)', borderRadius: 20,
          padding: '60px 40px', cursor: 'pointer'
        }}
      >
        {loading ? (
          <div>
            <div style={{ fontSize: 32, marginBottom: 16 }}>🔍</div>
            <div style={{ color: '#f59e0b' }}>AWS Rekognition analyzing...</div>
          </div>
        ) : (
          <div>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📸</div>
            <div style={{ fontSize: 18, marginBottom: 8 }}>Click to upload photo</div>
            <div style={{ color: 'rgba(245,240,232,0.4)', fontSize: 14 }}>JPG, PNG supported</div>
          </div>
        )}
      </div>

      {error && <div style={{ color: '#ef4444', marginTop: 16 }}>{error}</div>}

      <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }}
        onChange={e => handleFile(e.target.files[0])} />
    </div>
  )
}